angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
    .state('menu', {
      url: '/menu',
      abstract:true,
      templateUrl: 'templates/menu.html'
    })
        
    .state('menu.login', {
      url: '/login',
      views: {
        'side-menu21': {
          templateUrl: 'templates/login.html',
          controller: 'loginCtrl'
        }
      }
    })
        
    .state('menu.consultar', {
      url: '/find',
      views: {
        'side-menu21': {
          templateUrl: 'templates/consultar.html',
          controller: 'consultarCtrl'
        }
      }
    })      

    .state('menu.criar', {
      url: '/create',
      views: {
        'side-menu21': {
          templateUrl: 'templates/criar.html',
          controller: 'criarCtrl'
        }
      }
    })
        
    .state('menu.adesivo', {
      url: '/adhesive',
      views: {
          'side-menu21': {
            templateUrl: 'templates/adesivo.html',
            controller: 'adesivoCtrl'
          }
      }      
    })
        
    .state('menu.cartela', {
      url: '/cartouche',
      views: {
          'side-menu21': {
            templateUrl: 'templates/cartela.html',
            controller: 'cartelaCtrl'
          }
      }
    })
        
    .state('menu.folha', {
      url: '/leaf',
      views: {
          'side-menu21': {
            templateUrl: 'templates/folha.html',
            controller: 'folhaCtrl'
          }
      }

    })  
      
    ;

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/menu/login');

});