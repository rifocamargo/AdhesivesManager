angular.module('app.controllers', [])
  
.controller('loginCtrl', function($scope) {

})
      
.controller('consultarCtrl', function($scope) {

})
   
.controller('adesivoCtrl', function($scope) {

})
   
.controller('cartelaCtrl', function($scope) {

})
   
.controller('folhaCtrl', function($scope) {

})
   
.controller('criarCtrl', function($scope) {

})
 